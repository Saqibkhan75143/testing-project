<?php 

 session_start();
 $conn = mysqli_connect("localhost" , "root" , "");
         mysqli_select_db($conn , "fourm");
 session_destroy();
 echo "<script>window.open('login.php', '_self');</script>";



 ?>