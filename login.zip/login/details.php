<?php 
session_start();
$conn = mysqli_connect("localhost" , "root" , "");
        mysqli_select_db($conn , "fourm");

    
  
?>




<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
  <div class="container">
  	<?php 
            if (isset($_GET['id'])) {
                     $id = $_GET['id'];
          $query = "select * from posts where id='$id'";
           $result  = mysqli_query($conn, $query);
            
      

           while ($row = mysqli_fetch_array($result)) {?>
  	<div>
	<h1><a href="details.php"><?php echo $row['post_title']; ?></a></h1><hr>
	<p><?php echo $row['post_description']; ?></p>
    </div>
  
<?php }} ?>


  
     <h2 style="color:skyblue;">Comments:</h2>

     <?php 
          if (!isset($_SESSION['r_email'])) {
     echo "<a href='Login.php'>Login for Comments</a>";
    
          }

      ?>

  <?php 
      
      if (isset($_GET['id'])) {
          
          $postid =$_GET['id'];

            $query = "select * from comments where post_id='$postid'";
              $info =  mysqli_query($conn, $query);

              while ($salmankhan = mysqli_fetch_array($info)) {?>

	<div class="media">
  <div class="media-body">

    <?php echo $salmankhan['comment_description']; ?>
  </div>
</div>
<?php } }?>

	  <?php 
     
     if (!isset($_SESSION['r_email'])) {
       
     }

   ?>
   
     <?php if (!empty($_SESSION['login']) == true): ?>
      
   <h1>Leave a Comment</h1>
  <form action="" method="post" ><br><br><br>
   

      <?php 

       $post = "select * from posts";
            $result2 = mysqli_query($conn, $post);

            $row_comment = mysqli_fetch_array($result2);
      
       ?>


      <div class="form-group col-md-4">
        <input type="hidden" value="<?php echo $row_comment['id'] ?>"  name="id">
        <label>Comment description</label>
        <textarea rows="7" cols="45" name="textarea" class="form-control">
          
        </textarea>     
      </div>

      <div class="row p-4">
      
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" name="submit" class="btn btn-primary btn-block btn-flat">Add Comment</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
   <?php endif ?>

    <?php 
@session_start();
$conn = mysqli_connect("localhost" , "root" , "");
        mysqli_select_db($conn , "fourm");

        if (isset($_POST['submit'])){

          $textarea = $_POST['textarea'];
          

          $query  = "insert into comments (comment_description) value('$textarea') ";
          $result = mysqli_query($conn , $query);


          if ($result) {
            
            header("location:details.php?id=$id");

          }

          else{

            header('location:details.php?fail');

          }
        }


?>
</div>
</body>
</html>