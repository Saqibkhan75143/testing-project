<?php 
session_start();
$conn = mysqli_connect("localhost" , "root" , "");
        mysqli_select_db($conn , "fourm");

        if (isset($_POST['submit'])){

        	$email = $_POST['email'];
        	$pass  = $_POST['password'];

        	$query   = "select * from register where r_email = '$email' && r_password = '$pass' ";
        	$result  = mysqli_query($conn , $query);
        	$num     = mysqli_num_rows($result);

        	if ($num == true) {
        	
            $_SESSION['r_email'] = $email['r_email'];
        		$_SESSION['login'] = true;

        	
				header('location:index.php?success');

        	}
        	else{

        	header('location:login.php?failed');

        	}

        }


?>






<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
 <script src="bootstrap/js/bootstrap.min.js"></script>
</head>

<body>
<br><br><br>
<div class="container col-md-4">
      <form action="" method="post" class="border border-light p-5" >

  <h5 class="col-lg-12 card-header info-color white-text text-center py-4 my-2">
    <strong>Login Form</strong>
  </h5>


      

      <div class="form-group col-lg-12 my-4">

        <input type="email" name="email" class="form-control"  placeholder="Email">
      </div>

      <div class="form-group col-lg-12">

        <input type="password" name="password" class="form-control" placeholder="Password">
      </div>

      <div class="row p-4">
      
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" name="submit" class="btn btn-primary btn-block my-4">Submit</button>
          or <a href="register.php">Sign Up</a>
        </div>
        <!-- /.col -->
      </div>
    </form>
</div>
</body>
</html>