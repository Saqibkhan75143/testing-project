-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2019 at 08:16 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fourm`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(45) NOT NULL,
  `post_id` int(200) NOT NULL,
  `comment_description` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `comment_description`) VALUES
(43, 7, 'llllllllllllllllllllllllllllllllllllllllll    \r\n        '),
(44, 4, 'dddddddddd          \r\n        '),
(45, 4, '          \r\n        ffff\r\n'),
(46, 2, '   ggggg       \r\n        '),
(47, 2, '         ddddddddddddddddd \r\n        '),
(48, 4, '          \r\n        mmmmmmmmm'),
(49, 2, '          xxxxxxx\r\n        '),
(50, 2, '          xxxxx\r\n        '),
(51, 4, '          zzzzzzzzzzzzzz\r\n        '),
(52, 4, '          xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\r\n        '),
(53, 2, 'kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk\r\n        '),
(54, 2, '          \r\n        ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\r\n'),
(55, 2, '          xxxxxxxxx\r\n        '),
(56, 4, '          \r\n        xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'),
(57, 4, '          \r\n        ddddd'),
(58, 0, '          ddddddd\r\n        ');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `post_title` varchar(45) NOT NULL,
  `post_description` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `post_title`, `post_description`) VALUES
(2, 'Finding Articles and Journals via Google Scho', 'Lydia Dixon, Cheri Duncan, Jody Condit Fagan, Meris Mandernach and Stefanie E. Warlick\r\nReference & User Services Quarterly\r\nVol. 50, No. 2 (Winter 2010), pp. 170-181\r\nPublished by: American Library Association\r\nhttps://www.jstor.org/stable/20865386\r\nPage Count: 12'),
(3, '', '        	\r\n        '),
(4, 'Magento Developer', 'Job Description\r\nStart a career with the worldâ€™s largest virtual company!\r\n\r\nWork from anywhere â€“ Flexible hours â€“ Training & travel opportunities\r\n\r\nScopic Software is seeking a skilled Remote Magento Developer to join our team of 250+ professionals across 40 countries.\r\n\r\nAt Scopic, we believe great developers can be found in every corner of the globe, and talent shouldnâ€™t be limited by location. Our employees work in nearly every time zone, from whenever they feel most comfortable, an'),
(5, 'C# / WPF / C++/ Qt Developer', 'Job Description\r\nJoin the worldâ€™s largest virtual company!\r\n\r\nWork from anywhere â€“ Flexible hours â€“ Training & travel opportunities\r\n\r\nScopic Software is seeking a Remote C#/WPF and C++/Qt Developer (Intermediate level) to join our team of 250+ professionals across 40 countries. The successful applicant will work with a team of talented developers, designers, and project managers to develop industry-leading applications with the latest technologies.	\r\n        '),
(6, 'Branch Services Officer', 'Job Description\r\nUBL is looking to hire Branch Services Officers for Handling and executing all financial/non-financial transactions in accordance with bank policies and procedure while maintaining high service standards.        	\r\n        '),
(7, 'Hope Not Out', 'how are youhow are youhow are youhow are youhow are youhow are youhow are youhow are youhow are you.'),
(8, 'Hope Not Out', ' kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha kha        	\r\n        ');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `r_name` varchar(45) NOT NULL,
  `r_email` varchar(45) NOT NULL,
  `r_password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `r_name`, `r_email`, `r_password`) VALUES
(4, 'nokia', 'admin1@gmail.com', '12345'),
(5, 'vv', 'v@gmail', '12345'),
(6, 'nokia', 'admin1@gmail.com', '12345'),
(7, 'nokia', 'admin1@gmail.com', '12345'),
(8, 'nokia', 'admin1@gmail.com', '111'),
(9, 'salman', 'salman@gmail.com', 'salman'),
(10, 'khan', 'saqib@gmail.com', 'k'),
(11, '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(45) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
