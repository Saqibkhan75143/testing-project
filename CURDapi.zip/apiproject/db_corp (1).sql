-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 18, 2019 at 03:50 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_corp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`, `created_at`) VALUES
(1, 'allauddin2015@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '2018-06-30 12:54:14');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `ship_id` int(11) NOT NULL,
  `file_name` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `ship_id`, `file_name`, `created_at`) VALUES
(207, 0, 'upload/', '2019-10-11 09:43:01'),
(208, 0, 'upload/', '2019-10-11 09:43:44'),
(2, 5, 'file:lajflasjfljasl;fjals', '2018-07-03 14:58:53'),
(194, 0, 'upload/', '2019-10-09 11:38:13'),
(3, 1, 'http://divergense.com/corp/assets/uploads/20180703105904circular-shape-silhouette.png', '2018-07-03 14:59:04'),
(4, 2, 'http://divergense.com/corp/assets/uploads/20180704040544help-3.png', '2018-07-04 08:05:44'),
(5, 12, 'http://divergense.com/corp/assets/uploads/20180704042337file.png', '2018-07-04 08:23:37'),
(6, 12, 'http://divergense.com/corp/assets/uploads/20180704042438file.png', '2018-07-04 08:24:38'),
(7, 12, 'http://divergense.com/corp/assets/uploads/20180704042452file.png', '2018-07-04 08:24:53'),
(8, 12, 'http://divergense.com/corp/assets/uploads/20180704053351file.png', '2018-07-04 09:33:51'),
(9, 12, 'http://divergense.com/corp/assets/uploads/20180704053404file.png', '2018-07-04 09:34:04'),
(10, 12, 'http://divergense.com/corp/assets/uploads/20180704053459home-3.png', '2018-07-04 09:34:59'),
(11, 12, 'http://divergense.com/corp/assets/uploads/20180704053519file.png', '2018-07-04 09:35:19'),
(12, 12, 'http://divergense.com/corp/assets/uploads/20180704053533file.png', '2018-07-04 09:35:33'),
(13, 12, 'http://divergense.com/corp/assets/uploads/20180704053549file.png', '2018-07-04 09:35:49'),
(14, 12, 'http://divergense.com/corp/assets/uploads/20180704053617home-3.png', '2018-07-04 09:36:17'),
(15, 9, 'http://divergense.com/corp/assets/uploads/201807040732571530704006908.jpg', '2018-07-04 11:32:57'),
(16, 9, 'http://divergense.com/corp/assets/uploads/20180704082713picture.png', '2018-07-04 12:27:13'),
(17, 14, 'http://divergense.com/corp/assets/uploads/201807040907271530709663772.jpg', '2018-07-04 13:07:27'),
(18, 14, 'http://divergense.com/corp/assets/uploads/201807040914021530710071693.jpg', '2018-07-04 13:14:02'),
(19, 14, 'http://divergense.com/corp/assets/uploads/201807040914091530710071693.jpg', '2018-07-04 13:14:09'),
(20, 14, 'http://divergense.com/corp/assets/uploads/201807040914151530710071693.jpg', '2018-07-04 13:14:15'),
(21, 14, 'http://divergense.com/corp/assets/uploads/201807040919401530710409266.jpg', '2018-07-04 13:19:40'),
(22, 14, 'http://divergense.com/corp/assets/uploads/201807040919441530710409266.jpg', '2018-07-04 13:19:44'),
(23, 14, 'http://divergense.com/corp/assets/uploads/201807040919481530710409266.jpg', '2018-07-04 13:19:48'),
(24, 15, 'http://divergense.com/corp/assets/uploads/20180704092701C360_2018-07-03-22-30-48-938.jpg', '2018-07-04 13:27:01'),
(25, 15, 'http://divergense.com/corp/assets/uploads/20180704092708C360_2018-07-03-22-30-48-938.jpg', '2018-07-04 13:27:08'),
(26, 15, 'http://divergense.com/corp/assets/uploads/201807040928481528282604038.jpg', '2018-07-04 13:28:48'),
(27, 15, 'http://divergense.com/corp/assets/uploads/201807040928521528282604038.jpg', '2018-07-04 13:28:52'),
(28, 15, 'http://divergense.com/corp/assets/uploads/201807040928551528282604038.jpg', '2018-07-04 13:28:55'),
(29, 16, 'http://divergense.com/corp/assets/uploads/201807060813131530879193593.jpg', '2018-07-06 12:13:13'),
(30, 16, 'http://divergense.com/corp/assets/uploads/201807060813181530879193593.jpg', '2018-07-06 12:13:18'),
(31, 16, 'http://divergense.com/corp/assets/uploads/201807060813231530879193593.jpg', '2018-07-06 12:13:23'),
(32, 16, 'http://divergense.com/corp/assets/uploads/201807060835161530880546406.jpg', '2018-07-06 12:35:16'),
(33, 16, 'http://divergense.com/corp/assets/uploads/201807060835281530880546406.jpg', '2018-07-06 12:35:28'),
(34, 16, 'http://divergense.com/corp/assets/uploads/201807060835381530880546406.jpg', '2018-07-06 12:35:38'),
(35, 16, 'http://divergense.com/corp/assets/uploads/201807060835511530880546406.jpg', '2018-07-06 12:35:51'),
(36, 16, 'http://divergense.com/corp/assets/uploads/201807060835591530880546406.jpg', '2018-07-06 12:35:59'),
(37, 16, 'http://divergense.com/corp/assets/uploads/20180706083919IMG-20180706-WA0009.jpg', '2018-07-06 12:39:19'),
(38, 16, 'http://divergense.com/corp/assets/uploads/20180706083923IMG-20180706-WA0009.jpg', '2018-07-06 12:39:23'),
(39, 16, 'http://divergense.com/corp/assets/uploads/20180706083927IMG-20180706-WA0009.jpg', '2018-07-06 12:39:27'),
(40, 16, 'http://divergense.com/corp/assets/uploads/20180706083931IMG-20180706-WA0009.jpg', '2018-07-06 12:39:31'),
(41, 16, 'http://divergense.com/corp/assets/uploads/20180706084156IMG-20180706-WA0011.jpg', '2018-07-06 12:41:56'),
(42, 16, 'http://divergense.com/corp/assets/uploads/20180706084158IMG-20180706-WA0011.jpg', '2018-07-06 12:41:58'),
(43, 16, 'http://divergense.com/corp/assets/uploads/20180706084200IMG-20180706-WA0011.jpg', '2018-07-06 12:42:00'),
(44, 16, 'http://divergense.com/corp/assets/uploads/20180706084203IMG-20180706-WA0011.jpg', '2018-07-06 12:42:03'),
(45, 16, 'http://divergense.com/corp/assets/uploads/20180706084749IMG-20180706-WA0011.jpg', '2018-07-06 12:47:49'),
(46, 16, 'http://divergense.com/corp/assets/uploads/20180706084751IMG-20180706-WA0011.jpg', '2018-07-06 12:47:51'),
(47, 16, 'http://divergense.com/corp/assets/uploads/20180706084753IMG-20180706-WA0011.jpg', '2018-07-06 12:47:53'),
(48, 16, 'http://divergense.com/corp/assets/uploads/20180706084756IMG-20180706-WA0011.jpg', '2018-07-06 12:47:56'),
(49, 16, 'http://divergense.com/corp/assets/uploads/20180706084844IMG-20180706-WA0011.jpg', '2018-07-06 12:48:44'),
(50, 16, 'http://divergense.com/corp/assets/uploads/20180706084846IMG-20180706-WA0011.jpg', '2018-07-06 12:48:46'),
(51, 16, 'http://divergense.com/corp/assets/uploads/20180706084848IMG-20180706-WA0011.jpg', '2018-07-06 12:48:48'),
(52, 16, 'http://divergense.com/corp/assets/uploads/20180706085130IMG-20180706-WA0011.jpg', '2018-07-06 12:51:30'),
(53, 16, 'http://divergense.com/corp/assets/uploads/20180706085132IMG-20180706-WA0011.jpg', '2018-07-06 12:51:32'),
(54, 16, 'http://divergense.com/corp/assets/uploads/20180706085134IMG-20180706-WA0011.jpg', '2018-07-06 12:51:34'),
(55, 16, 'http://divergense.com/corp/assets/uploads/20180706085137IMG-20180706-WA0011.jpg', '2018-07-06 12:51:37'),
(56, 16, 'http://divergense.com/corp/assets/uploads/20180706085244IMG-20180706-WA0011.jpg', '2018-07-06 12:52:44'),
(57, 16, 'http://divergense.com/corp/assets/uploads/20180706085247IMG-20180706-WA0011.jpg', '2018-07-06 12:52:47'),
(58, 16, 'http://divergense.com/corp/assets/uploads/20180706085414IMG-20180706-WA0011.jpg', '2018-07-06 12:54:14'),
(59, 16, 'http://divergense.com/corp/assets/uploads/20180706085416IMG-20180706-WA0011.jpg', '2018-07-06 12:54:16'),
(60, 16, 'http://divergense.com/corp/assets/uploads/20180706085419IMG-20180706-WA0011.jpg', '2018-07-06 12:54:19'),
(61, 16, 'http://divergense.com/corp/assets/uploads/20180706085422IMG-20180706-WA0011.jpg', '2018-07-06 12:54:22'),
(62, 16, 'http://divergense.com/corp/assets/uploads/20180706090250IMG-20180706-WA0011.jpg', '2018-07-06 13:02:50'),
(63, 16, 'http://divergense.com/corp/assets/uploads/20180706090252IMG-20180706-WA0011.jpg', '2018-07-06 13:02:52'),
(64, 16, 'http://divergense.com/corp/assets/uploads/20180706090255IMG-20180706-WA0011.jpg', '2018-07-06 13:02:55'),
(65, 16, 'http://divergense.com/corp/assets/uploads/20180706090258IMG-20180706-WA0011.jpg', '2018-07-06 13:02:58'),
(66, 16, 'http://divergense.com/corp/assets/uploads/20180706090538IMG-20180706-WA0011.jpg', '2018-07-06 13:05:38'),
(67, 16, 'http://divergense.com/corp/assets/uploads/20180706090544IMG-20180706-WA0011.jpg', '2018-07-06 13:05:44'),
(68, 16, 'http://divergense.com/corp/assets/uploads/20180706090550IMG-20180706-WA0011.jpg', '2018-07-06 13:05:50'),
(69, 16, 'http://divergense.com/corp/assets/uploads/20180706090557IMG-20180706-WA0011.jpg', '2018-07-06 13:05:57'),
(70, 16, 'http://divergense.com/corp/assets/uploads/20180706090959IMG-20180706-WA0011.jpg', '2018-07-06 13:09:59'),
(71, 16, 'http://divergense.com/corp/assets/uploads/20180706091003IMG-20180706-WA0011.jpg', '2018-07-06 13:10:03'),
(72, 16, 'http://divergense.com/corp/assets/uploads/20180706091004IMG-20180706-WA0011.jpg', '2018-07-06 13:10:04'),
(73, 16, 'http://divergense.com/corp/assets/uploads/20180706091005IMG-20180706-WA0011.jpg', '2018-07-06 13:10:05'),
(74, 16, 'http://divergense.com/corp/assets/uploads/20180706091013IMG-20180706-WA0011.jpg', '2018-07-06 13:10:13'),
(75, 16, 'http://divergense.com/corp/assets/uploads/20180706092520IMG-20180706-WA0011.jpg', '2018-07-06 13:25:20'),
(76, 16, 'http://divergense.com/corp/assets/uploads/20180706092523IMG-20180706-WA0011.jpg', '2018-07-06 13:25:23'),
(77, 16, 'http://divergense.com/corp/assets/uploads/20180706092526IMG-20180706-WA0011.jpg', '2018-07-06 13:25:26'),
(78, 16, 'http://divergense.com/corp/assets/uploads/20180706092529IMG-20180706-WA0011.jpg', '2018-07-06 13:25:29'),
(79, 16, 'http://divergense.com/corp/assets/uploads/20180706092536IMG-20180706-WA0011.jpg', '2018-07-06 13:25:36'),
(80, 16, 'http://divergense.com/corp/assets/uploads/20180706092637IMG-20180706-WA0011.jpg', '2018-07-06 13:26:37'),
(81, 16, 'http://divergense.com/corp/assets/uploads/20180706092640IMG-20180706-WA0011.jpg', '2018-07-06 13:26:40'),
(82, 16, 'http://divergense.com/corp/assets/uploads/20180706092647IMG-20180706-WA0011.jpg', '2018-07-06 13:26:47'),
(83, 16, 'http://divergense.com/corp/assets/uploads/20180706092651IMG-20180706-WA0011.jpg', '2018-07-06 13:26:51'),
(84, 16, 'http://divergense.com/corp/assets/uploads/20180706092656IMG-20180706-WA0011.jpg', '2018-07-06 13:26:56'),
(85, 20, 'http://divergense.com/corp/assets/uploads/20180706095047UPHOTO_20180703_100215.jpg', '2018-07-06 13:50:47'),
(86, 20, 'http://divergense.com/corp/assets/uploads/20180706095246UPHOTO_20180703_100215.jpg', '2018-07-06 13:52:46'),
(87, 20, 'http://divergense.com/corp/assets/uploads/20180706101113gly.PNG', '2018-07-06 14:11:13'),
(88, 20, 'http://divergense.com/corp/assets/uploads/20180706101115gly.PNG', '2018-07-06 14:11:15'),
(89, 18, 'http://divergense.com/corp/assets/uploads/201807090431441531168303908.jpg', '2018-07-09 20:31:44'),
(90, 18, 'http://divergense.com/corp/assets/uploads/201807090431551531168303908.jpg', '2018-07-09 20:31:55'),
(91, 10, 'http://divergense.com/corp/assets/uploads/201807090432571531168377604.jpg', '2018-07-09 20:32:57'),
(92, 10, 'http://divergense.com/corp/assets/uploads/201807090445281531169128786.jpg', '2018-07-09 20:45:28'),
(93, 10, 'http://divergense.com/corp/assets/uploads/201807090445401531169128786.jpg', '2018-07-09 20:45:40'),
(94, 19, 'http://divergense.com/corp/assets/uploads/201807090446201531169180802.jpg', '2018-07-09 20:46:20'),
(95, 19, 'http://divergense.com/corp/assets/uploads/201807090446271531169180802.jpg', '2018-07-09 20:46:27'),
(96, 22, 'http://divergense.com/corp/assets/uploads/201807090447031531169223481.jpg', '2018-07-09 20:47:03'),
(97, 22, 'http://divergense.com/corp/assets/uploads/201807090447101531169223481.jpg', '2018-07-09 20:47:10'),
(98, 22, 'http://divergense.com/corp/assets/uploads/201807090447301531169223481.jpg', '2018-07-09 20:47:30'),
(99, 7, 'http://divergense.com/corp/assets/uploads/201807120532231531387970066.jpg', '2018-07-12 09:32:23'),
(100, 21, 'http://divergense.com/corp/assets/uploads/201807120145191531417520598.jpg', '2018-07-12 17:45:19'),
(101, 21, 'http://divergense.com/corp/assets/uploads/201807120145301531417520598.jpg', '2018-07-12 17:45:30'),
(102, 24, 'http://divergense.com/corp/assets/uploads/201807120200321531418433111.jpg', '2018-07-12 18:00:32'),
(103, 23, 'http://divergense.com/corp/assets/uploads/201807120201151531418476706.jpg', '2018-07-12 18:01:15'),
(104, 2, 'http://divergense.com/corp/assets/uploads/20180717054811picture.png', '2018-07-17 09:48:11'),
(105, 2, 'http://divergense.com/corp/assets/uploads/20180717054818pencil-edit-button.png', '2018-07-17 09:48:18'),
(106, 2, 'http://divergense.com/corp/assets/uploads/20180717054825remove.png', '2018-07-17 09:48:25'),
(107, 7, 'http://divergense.com/corp/assets/uploads/20180718121232file.png', '2018-07-18 04:12:32'),
(108, 7, 'http://divergense.com/corp/assets/uploads/20180718121305file.png', '2018-07-18 04:13:05'),
(109, 20, 'http://divergense.com/corp/assets/uploads/20180718121357file.png', '2018-07-18 04:13:57'),
(110, 20, 'http://divergense.com/corp/assets/uploads/20180718121504file.png', '2018-07-18 04:15:04'),
(111, 20, 'http://divergense.com/corp/assets/uploads/20180718121532bgSearch.png', '2018-07-18 04:15:32'),
(112, 8, 'http://divergense.com/corp/assets/uploads/20180718020834file.png', '2018-07-18 06:08:34'),
(113, 8, 'http://divergense.com/corp/assets/uploads/20180718020851file.png', '2018-07-18 06:08:51'),
(114, 8, 'http://divergense.com/corp/assets/uploads/20180718020905file.png', '2018-07-18 06:09:05'),
(115, 8, 'http://divergense.com/corp/assets/uploads/20180718020921file.png', '2018-07-18 06:09:21'),
(116, 25, 'http://divergense.com/corp/assets/uploads/20180718021005file.png', '2018-07-18 06:10:05'),
(117, 25, 'http://divergense.com/corp/assets/uploads/20180718021012file.png', '2018-07-18 06:10:12'),
(118, 25, 'http://divergense.com/corp/assets/uploads/20180718021030file.png', '2018-07-18 06:10:30'),
(119, 25, 'http://divergense.com/corp/assets/uploads/20180718021055file.png', '2018-07-18 06:10:55'),
(120, 25, 'http://divergense.com/corp/assets/uploads/20180718021105file.png', '2018-07-18 06:11:05'),
(121, 30, 'http://divergense.com/corp/assets/uploads/20180718054942file.png', '2018-07-18 09:49:42'),
(122, 30, 'http://divergense.com/corp/assets/uploads/20180718055003file.png', '2018-07-18 09:50:03'),
(123, 30, 'http://divergense.com/corp/assets/uploads/20180718055015file.png', '2018-07-18 09:50:15'),
(124, 30, 'http://divergense.com/corp/assets/uploads/20180718055032file.png', '2018-07-18 09:50:32'),
(125, 30, 'http://divergense.com/corp/assets/uploads/20180718055046file.png', '2018-07-18 09:50:46'),
(126, 30, 'http://divergense.com/corp/assets/uploads/20180718055112file.png', '2018-07-18 09:51:12'),
(127, 30, 'http://divergense.com/corp/assets/uploads/20180718055245file.png', '2018-07-18 09:52:45'),
(128, 30, 'http://divergense.com/corp/assets/uploads/20180718055302file.png', '2018-07-18 09:53:02'),
(129, 30, 'http://divergense.com/corp/assets/uploads/20180718055318file.png', '2018-07-18 09:53:18'),
(130, 30, 'http://divergense.com/corp/assets/uploads/20180718055331file.png', '2018-07-18 09:53:31'),
(131, 30, 'http://divergense.com/corp/assets/uploads/20180718055345file.png', '2018-07-18 09:53:45'),
(132, 30, 'http://divergense.com/corp/assets/uploads/20180718061030file.png', '2018-07-18 10:10:30'),
(133, 23, 'http://divergense.com/corp/assets/uploads/20180720122744file.png', '2018-07-20 16:27:44'),
(134, 23, 'http://divergense.com/corp/assets/uploads/20180720122756file.png', '2018-07-20 16:27:56'),
(135, 31, 'http://divergense.com/corp/assets/uploads/20180720123239file.png', '2018-07-20 16:32:39'),
(136, 31, 'http://divergense.com/corp/assets/uploads/20180720123246file.png', '2018-07-20 16:32:46'),
(137, 30, 'http://divergense.com/corp/assets/uploads/20180722032837file.png', '2018-07-22 19:28:37'),
(138, 30, 'http://divergense.com/corp/assets/uploads/20180722032916file.png', '2018-07-22 19:29:16'),
(139, 30, 'http://divergense.com/corp/assets/uploads/20180722032926file.png', '2018-07-22 19:29:26'),
(140, 35, 'http://divergense.com/corp/assets/uploads/20180723060900Screenshot_20180721-005332.png', '2018-07-23 10:09:00'),
(141, 35, 'http://divergense.com/corp/assets/uploads/201807230622201532341323115.jpg', '2018-07-23 10:22:20'),
(142, 35, 'http://divergense.com/corp/assets/uploads/2018072306265520180723_152159.jpg', '2018-07-23 10:26:55'),
(143, 38, 'http://divergense.com/corp/assets/uploads/201807230636371532342180354.jpg', '2018-07-23 10:36:37'),
(144, 37, 'http://divergense.com/corp/assets/uploads/201807230638201532341323115.jpg', '2018-07-23 10:38:20'),
(145, 37, 'http://divergense.com/corp/assets/uploads/201807230643161532341323115.jpg', '2018-07-23 10:43:16'),
(146, 37, 'http://divergense.com/corp/assets/uploads/201807230644351532341323115.jpg', '2018-07-23 10:44:35'),
(147, 37, 'http://divergense.com/corp/assets/uploads/201807230645421532341323115.jpg', '2018-07-23 10:45:42'),
(148, 37, 'http://divergense.com/corp/assets/uploads/201807230650081532341323115.jpg', '2018-07-23 10:50:08'),
(149, 38, 'http://divergense.com/corp/assets/uploads/20180723065231IMG_1531033139170.jpg', '2018-07-23 10:52:31'),
(150, 38, 'http://divergense.com/corp/assets/uploads/201807230657481532341323115.jpg', '2018-07-23 10:57:48'),
(151, 38, 'http://divergense.com/corp/assets/uploads/201807230700191532342180354.jpg', '2018-07-23 11:00:19'),
(152, 38, 'http://divergense.com/corp/assets/uploads/201807230704341532342180354.jpg', '2018-07-23 11:04:34'),
(153, 40, 'http://divergense.com/corp/assets/uploads/20180723123300file.png', '2018-07-23 16:33:00'),
(154, 2, 'http://divergense.com/corp/assets/uploads/201807231235091532363709991.jpg', '2018-07-23 16:35:09'),
(155, 40, 'http://divergense.com/corp/assets/uploads/201807230154081532342180354.jpg', '2018-07-23 17:54:08'),
(156, 40, 'http://divergense.com/corp/assets/uploads/201807230202121532342180354.jpg', '2018-07-23 18:02:12'),
(157, 39, 'http://divergense.com/corp/assets/uploads/201807230203351532342180354.jpg', '2018-07-23 18:03:35'),
(158, 39, 'http://divergense.com/corp/assets/uploads/201807230206141532342180354.jpg', '2018-07-23 18:06:14'),
(159, 36, 'http://divergense.com/corp/assets/uploads/20180723021107received_259849174551507.jpeg', '2018-07-23 18:11:07'),
(160, 36, 'http://divergense.com/corp/assets/uploads/20180723021235received_259849174551507.jpeg', '2018-07-23 18:12:35'),
(161, 36, 'http://divergense.com/corp/assets/uploads/20180723021433IMG_20180720_123533_502.jpg', '2018-07-23 18:14:33'),
(162, 17, 'http://divergense.com/corp/assets/uploads/20180723021647received_259849174551507.jpeg', '2018-07-23 18:16:47'),
(163, 41, 'http://divergense.com/corp/assets/uploads/201807230419311532377172713.jpg', '2018-07-23 20:19:31'),
(164, 41, 'http://divergense.com/corp/assets/uploads/20180723042054file.png', '2018-07-23 20:20:54'),
(165, 45, 'http://divergense.com/corp/assets/uploads/201807240200591532342180354.jpg', '2018-07-24 06:00:59'),
(166, 44, 'http://divergense.com/corp/assets/uploads/20180724082154IMG_1531033139170.jpg', '2018-07-24 12:21:54'),
(167, 44, 'http://divergense.com/corp/assets/uploads/20180724082159IMG_1531033139170.jpg', '2018-07-24 12:21:59'),
(168, 42, 'http://divergense.com/corp/assets/uploads/2018072408242720180724_141911.jpg', '2018-07-24 12:24:27'),
(169, 42, 'http://divergense.com/corp/assets/uploads/2018072408245020180724_141911.jpg', '2018-07-24 12:24:50'),
(170, 43, 'http://divergense.com/corp/assets/uploads/20180724084535received_259849177884840.jpeg', '2018-07-24 12:45:35'),
(171, 42, 'http://divergense.com/corp/assets/uploads/20180724090330received_259849174551507.jpeg', '2018-07-24 13:03:30'),
(172, 43, 'http://divergense.com/corp/assets/uploads/201807241248151532450896143.jpg', '2018-07-24 16:48:15'),
(173, 51, 'http://divergense.com/corp/assets/uploads/20180724010907file.png', '2018-07-24 17:09:07'),
(174, 52, 'http://divergense.com/corp/assets/uploads/20180724011045file.png', '2018-07-24 17:10:45'),
(175, 52, 'http://divergense.com/corp/assets/uploads/20180724011051file.png', '2018-07-24 17:10:51'),
(176, 43, 'http://divergense.com/corp/assets/uploads/201807240119351532452775574.jpg', '2018-07-24 17:19:35'),
(177, 48, 'http://divergense.com/corp/assets/uploads/2018072701401020180712_154315.png', '2018-07-27 05:40:10'),
(178, 48, 'http://divergense.com/corp/assets/uploads/2018072701404320180712_154315.png', '2018-07-27 05:40:43'),
(179, 1, 'http://divergense.com/corp/assets/uploads/201807270641191532341323115.jpg', '2018-07-27 10:41:19'),
(180, 1, 'http://divergense.com/corp/assets/uploads/201807270642271532341323115.jpg', '2018-07-27 10:42:27'),
(181, 2, 'http://divergense.com/corp/assets/uploads/20180730015659dollar-1971103_1920.jpg', '2018-07-30 05:56:59'),
(182, 2, 'http://divergense.com/corp/assets/uploads/20180730022802cam_white.png', '2018-07-30 06:28:02'),
(183, 49, 'http://divergense.com/corp/assets/uploads/20180730023841file.png', '2018-07-30 06:38:41'),
(184, 4, 'http://divergense.com/corp/assets/uploads/20180730024749Screenshot_20180729-040555.png', '2018-07-30 06:47:49'),
(185, 8, 'http://divergense.com/corp/assets/uploads/20180730024814Screenshot_20180724-173508.png', '2018-07-30 06:48:14'),
(186, 11, 'http://divergense.com/corp/assets/uploads/201904040156351554357393780.jpg', '2019-04-04 05:56:35'),
(187, 11, 'http://divergense.com/corp/assets/uploads/201904040156421554357393780.jpg', '2019-04-04 05:56:42'),
(188, 11, 'http://divergense.com/corp/assets/uploads/201904040157271554357393780.jpg', '2019-04-04 05:57:27'),
(189, 10, 'http://divergense.com/corp/assets/uploads/20190404020548IMG_20190320_010302.jpg', '2019-04-04 06:05:48'),
(190, 10, 'http://divergense.com/corp/assets/uploads/20190404025901IMG_20190320_010302.jpg', '2019-04-04 06:59:01'),
(191, 13, 'http://divergense.com/corp/assets/uploads/20190404033807IMG_20190320_010302.jpg', '2019-04-04 07:38:07'),
(192, 20, 'http://divergense.com/corp/assets/uploads/20190408012005IMG_20190407_191123.jpg', '2019-04-08 05:20:05'),
(193, 5, 'http:jfklsjflasjlf;sajldj', '2019-09-25 11:45:22'),
(209, 0, 'upload/', '2019-10-11 09:46:53'),
(210, 0, 'upload/', '2019-10-11 09:48:30'),
(211, 0, 'upload/10411793_744878385647925_6332626790571695545_n.jpg', '2019-10-11 09:52:16'),
(212, 0, '735033_206138089741704_3594223860176794200_n.jpg', '2019-10-11 09:54:19'),
(213, 0, '', '2019-10-11 09:56:47'),
(214, 0, '10411793_744878385647925_6332626790571695545_n1.jpg', '2019-10-11 09:59:30');

-- --------------------------------------------------------

--
-- Table structure for table `shipments`
--

CREATE TABLE `shipments` (
  `id` int(11) NOT NULL,
  `arrived_date` datetime NOT NULL,
  `order_no` varchar(30) NOT NULL,
  `customer` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `notes_shipping` text NOT NULL,
  `notes_production` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0',
  `delivered_date` date DEFAULT NULL,
  `shipment_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shipments`
--

INSERT INTO `shipments` (`id`, `arrived_date`, `order_no`, `customer`, `description`, `notes_shipping`, `notes_production`, `user_id`, `created_at`, `status`, `delivered_date`, `shipment_date`) VALUES
(2, '2018-06-08 00:00:00', 'PG125', 'Ali Rehman', 'This is simple description', 'This is simple Shipment description', 'This is simple Production description', 1, '2018-07-30 06:28:57', 1, '0000-00-00', '2018-06-26'),
(3, '2018-06-08 00:00:00', 'PG125', 'Kashif Ahmad', 'This is simple description', 'This is simple Shipment description', 'This is simple Production description', 6, '2018-06-26 07:57:42', 1, '0000-00-00', '2018-06-26'),
(4, '2018-06-08 00:00:00', 'PG125', 'Kashif Ahmad', 'This is simple description', 'This is simple Shipment description', 'This is simple Production description', 6, '2018-07-30 06:47:14', 1, '2018-06-27', '2018-06-28'),
(5, '2018-06-08 00:00:00', 'PG125', 'Kashif Ahmad', 'This is simple description', 'This is simple Shipment description', 'This is simple Production description', 6, '2018-06-27 08:28:14', 1, '2018-06-27', '2018-06-28'),
(6, '2018-06-08 00:00:00', 'PG125', 'Ali Rehman', 'This is simple description', 'This is simple Shipment description', 'This is simple Production description', 4, '2018-06-27 10:49:49', 1, '2018-06-27', '2018-06-26'),
(7, '2018-06-08 00:00:00', 'PG125', 'Kashif Ahmad', 'This is simple description', 'This is simple Shipment description', 'Ahmad', 4, '2018-07-18 04:13:10', 1, '2018-06-27', '2018-06-28'),
(8, '2018-06-08 00:00:00', 'PG125', 'Kashif Ahmad', 'This is simple description', 'This is simple Shipment description', 'This is simple Production description', 4, '2018-07-30 06:47:53', 1, '2018-06-27', '2018-06-28'),
(9, '2018-06-14 00:00:00', '12312', '12312', 'sdmf', 'sdafsdfa', 'kjsdf', 4, '2018-07-04 12:38:17', 1, NULL, NULL),
(10, '2018-07-13 00:00:00', '', 'Geoffrey Branagh', 'TEST', '', 'Hello', 1, '2019-04-04 06:59:08', 1, NULL, NULL),
(11, '2018-12-07 00:00:00', 'KAT SMELL', 'fsgfs', 'das', '', 'This is the first time im editing to check the textviw lines and it can b any thing so dont bother', 4, '2019-04-04 06:00:44', 1, NULL, '0000-00-00'),
(12, '2018-07-09 00:00:00', '2123', 'Ahmad', 'Hello ', 'Blah Blah', 'Nothing', 6, '2018-07-04 09:35:57', 1, NULL, NULL),
(13, '2018-07-04 00:00:00', 'OR123', 'John Doe', 'description here', 'description here', 'Changing', 4, '2019-04-04 07:38:15', 1, NULL, '2018-07-11'),
(14, '2018-04-07 00:00:00', '123123', 'Adam', 'Description', 'shipping notes', 'production notes', 4, '2018-07-04 13:19:49', 1, NULL, '2018-11-07'),
(15, '2018-07-01 00:00:00', '111111', 'Jhony sin', 'des', 'ship', 'pro', 4, '2018-07-04 13:29:05', 1, NULL, '2018-07-09'),
(16, '2018-07-03 00:00:00', '112211', 'sunny leone', 'des', 'ship', 'producrt', 4, '2018-07-06 13:27:06', 1, NULL, '2018-07-10'),
(17, '1969-12-31 00:00:00', '', '', '', '', '', 0, '2018-07-23 18:16:49', 1, NULL, '1970-01-07'),
(18, '1969-12-31 00:00:00', 'PG 150501', 'NEW TEST', '', 'OK FOR HOLES\r\n', '', 1, '2018-07-09 20:32:00', 1, NULL, '1969-12-31'),
(19, '2018-07-06 00:00:00', '', 'TEST 2', '', '', '', 1, '2018-07-09 20:46:28', 1, NULL, '2018-07-13'),
(20, '2018-07-06 00:00:00', '98236', 'spiderman', 'adadlkjflaj', 'lkhsdf', 'Changer', 4, '2019-04-08 05:20:11', 1, NULL, '2018-07-13'),
(21, '2018-07-09 00:00:00', 'k', 'John Doe', 'Test', 'Test', 'Test', 1, '2018-07-09 10:25:42', 2, NULL, '2018-07-13'),
(22, '2018-07-05 00:00:00', 'N/A', 'Geoff New Test', '', '', '', 1, '2018-07-13 18:04:19', 1, NULL, '2018-09-07'),
(23, '2018-07-06 00:00:00', '', '3 Day Test', '', '', 'My Note', 1, '2018-07-20 16:28:00', 1, NULL, '2018-07-13'),
(26, '2018-07-06 00:00:00', '834', 'Qari', '', '', '', 4, '2018-07-23 09:58:44', 2, NULL, '2018-07-13'),
(27, '2018-07-17 00:00:00', '23123', 'Ahmad', 'sadasasfdasdfasdf', 'dsaasdfsdafasdf', 'Ahmad Che', 6, '2018-07-18 09:23:07', 2, NULL, '2018-07-24'),
(28, '2018-07-21 00:00:00', 'qw2121', 'Ahmad', 'fdsdfsdfsdf', 'sfgddfgsdg', 'dfgsdfgsdfgdsgasdfsadfasdfasdfasdfasdfasdfasdf', 6, '2018-07-18 10:08:58', 2, NULL, '2018-07-30'),
(29, '2018-07-21 00:00:00', '234332', 'Ahmad', 'adsfsadfsd', 'sdfasdfasdf', 'sdfasfasfd', 7, '2018-07-18 09:26:28', 2, NULL, '2018-07-30'),
(30, '2018-07-20 00:00:00', '211122', 'dsafdsf', 'dsfsadf', 'sadfasdfasd', 'sdfasdfasfdfdgsdfgdfgssdfgdfsggdfsdfgssdfgdfgs', 6, '2018-07-22 19:29:35', 1, NULL, '2018-07-27'),
(31, '2018-07-20 00:00:00', 'PG15533', 'NEW TEST 7/20', 'BEAMS', 'OK FOR HOLES', 'Test notes', 1, '2018-07-20 16:32:51', 1, NULL, '2018-07-27'),
(32, '2018-07-24 00:00:00', '23123', 'Ahmad', 'Dasasdasd', 'asdasdas', 'dsaasasd', 1, '2018-07-22 19:35:21', 2, NULL, '1969-12-31'),
(33, '2018-07-24 00:00:00', 'dfxc343', 'Ahmad', 'sdfasdf', 'sdasfd', 'sfdsadf', 1, '2018-07-23 07:34:44', 2, NULL, '1969-12-31'),
(34, '2018-07-24 00:00:00', 'cxccxxc', 'dsafdsf', 'xzcxczxc', 'adsasasd', 'asdasdas', 6, '2018-07-23 09:35:26', 2, NULL, '2018-07-31'),
(35, '2018-07-17 00:00:00', '928364', 'Adam', '', '', '', 9, '2018-07-23 10:28:12', 1, NULL, '2018-07-24'),
(36, '2018-07-26 00:00:00', '3545', 'noor', '', '', '', 4, '2018-07-23 18:14:07', 1, NULL, '2018-08-02'),
(37, '2018-07-19 00:00:00', '834', 'abcd', '', '', '', 9, '2018-07-23 10:50:18', 1, NULL, '2018-07-26'),
(38, '2018-07-19 00:00:00', '89345', 'xyz', 'abc', 'abc', 'abc', 9, '2018-07-23 11:04:40', 1, NULL, '2018-07-26'),
(39, '2018-07-24 00:00:00', 'eweds', 'Ahmad', 'sadasddsf', 'sdfasdfasdfs', 'sdfasdfasdf', 6, '2018-07-23 18:08:11', 2, NULL, '2018-07-31'),
(40, '2018-07-23 00:00:00', 'PG 111555', 'Test on 7/23', 'Beams and Brackets', 'ok for holes', '', 1, '2018-07-23 18:02:15', 1, NULL, '2018-07-30'),
(41, '2018-07-23 00:00:00', 'pg 123563', 'TEST 7/23 afternoon', 'beams', '', '', 0, '2018-07-23 20:21:05', 2, NULL, '2018-07-30'),
(42, '2018-07-23 00:00:00', 'work day test', 'american metals', 'testing', '', '', 0, '2018-07-24 13:03:37', 1, NULL, '2018-07-30'),
(43, '2018-07-24 00:00:00', 'work day test 2', '', 'more test', '', 'noted', 0, '2018-07-24 17:23:44', 2, NULL, '2018-07-31'),
(44, '2018-07-15 00:00:00', '9053', 'Matt', '', '', '', 0, '2018-07-24 16:46:47', 2, NULL, '2018-07-23'),
(45, '2018-07-14 00:00:00', '78634', 'laty', '', '', '', 0, '2018-07-24 16:46:37', 2, NULL, '2018-07-23'),
(46, '2018-07-18 00:00:00', 'PG TEST !@#$', 'DATE TEST', 'dsagfdsa', '', '', 0, '2018-07-24 16:54:58', 2, NULL, '2018-07-25'),
(47, '2018-07-19 00:00:00', '', '', '', '', '', 0, '2019-04-04 06:03:54', 2, NULL, '2018-07-26'),
(48, '2018-07-20 00:00:00', '', '', '', '', '', 0, '2019-04-04 06:04:00', 2, NULL, '2018-07-27'),
(49, '2018-07-23 00:00:00', '', '', '', '', '', 0, '2018-07-30 06:38:45', 1, NULL, '2018-07-30'),
(50, '2018-07-24 00:00:00', '12345', 'Geoffrey Branagh', 'test', 'test', '', 0, '2018-07-24 17:05:24', 2, NULL, '2018-07-31'),
(51, '2018-07-24 00:00:00', 'testkt', '', 'test', 'test', 'Need holes', 0, '2018-07-24 17:09:28', 1, NULL, '2018-07-31'),
(52, '2018-07-24 00:00:00', 'kttest2', 'Geoffrey Branagh', 'test', 'test', 'Need holes', 0, '2018-07-24 17:15:01', 2, NULL, '2018-07-31'),
(53, '2018-07-26 00:00:00', '863', 'Adam Noor', 'This is material description. We are testing this. Let\'s see what happened.', 'This is shipping notes. We are testing this. Let\'s see what happened.', 'This is production notes. We are testing this. Let\'s see what happened.', 0, '2019-04-04 06:03:38', 2, NULL, '2018-08-02'),
(54, '2018-08-07 00:00:00', '12121212121221', 'Date Test August 7', 'Some stuff', '', '', 0, '2019-04-04 05:52:50', 2, NULL, '2018-08-12'),
(55, '2018-09-26 00:00:00', '3423', 'new order', 'abc', 'xyz', '', 0, '2019-04-04 05:55:45', 2, NULL, '2018-10-03'),
(56, '1969-12-31 00:00:00', '86', 'no name', 'abc', '', 'Hi there testing', 9, '2019-04-04 05:55:07', 2, NULL, '2018-04-10'),
(57, '1969-12-31 00:00:00', '32r32', 'adam khan', 'dg', 'sgdg', 'sdg', 1, '2019-04-11 06:16:48', 2, NULL, '2018-08-10'),
(58, '1970-01-01 00:00:00', '555', 'Abdullah Khan', 'my testing', 'testing', 'testing', 1, '2019-04-11 06:56:39', 2, NULL, '1970-01-01'),
(59, '2019-04-04 00:00:00', '645', 'Adam', 'hello testings', 'testing', 'testings', 1, '2019-04-11 06:17:57', 1, NULL, '2019-04-11'),
(60, '2019-10-23 00:00:00', '12312', 'John Doe', 'dsafasd', 'dsfasd', 'adsfads', 1, '2019-04-11 06:59:06', 0, NULL, '2019-10-22'),
(61, '0000-00-00 00:00:00', 'kh00', 'khan', 'sanga ye', 'kha yaama', 'sahe da', 4, '2019-09-24 20:02:00', 1, NULL, NULL),
(62, '0000-00-00 00:00:00', 'kh00', 'khan', 'sanga ye', 'kha yaama', 'sahe da', 4, '2019-09-24 20:03:23', 1, NULL, NULL),
(63, '0000-00-00 00:00:00', 'kh00', 'khan', 'sanga ye', 'kha yaama', 'sahe da', 0, '2019-09-24 20:03:49', 1, NULL, NULL),
(64, '0000-00-00 00:00:00', 'kh00', 'khan', 'sanga ye', 'kha yaama', 'sahe da', 3, '2019-09-24 20:05:31', 1, NULL, NULL),
(65, '0000-00-00 00:00:00', 'kh00', 'khan', 'sanga ye', 'kha yaama', 'sahe da', 4, '2019-09-24 20:06:38', 1, NULL, NULL),
(69, '0000-00-00 00:00:00', 'kh000', 'khan', 'sanga ye', 'kha yaama', 'sahe da', 3, '2019-09-25 08:04:14', 2, NULL, NULL),
(70, '0000-00-00 00:00:00', 'pg000', 'saqib', 'khansfjls;jf;lsjf;lsj', 'ddshksh', 'kkdkhskd', 7, '2019-09-30 10:51:18', 5, NULL, NULL),
(71, '0000-00-00 00:00:00', '444', 'khann', 'sjflsjfl', 'dfdfdfd', 'dddddddddddsss', 4, '2019-09-30 11:28:34', 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `first_name`, `last_name`, `password`, `created_at`) VALUES
(1, 'allauddin2015@gmail.com', 'Allauddin', 'Yousafzai', '21232f297a57a5a743894a0e4a801fc3', '2018-06-26 19:36:46'),
(3, 'saqibkhan5757@gmail.com', 'saqibbb', 'khan', 'fde9264cf376fffe2ee4ddf4a988880d', '2019-09-25 07:35:34'),
(5, 'saqib5@gmail.com', 'saqib', 'khan', '15de21c670ae7c3f6f3f1f37029303c9', '2019-09-30 11:52:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shipments`
--
ALTER TABLE `shipments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=215;
--
-- AUTO_INCREMENT for table `shipments`
--
ALTER TABLE `shipments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
