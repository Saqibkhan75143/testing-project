<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Imgapi extends CI_Controller
{
	public function iget()
	{
		$img = array(
            'id' => $this->input->post('id')
		);

		$get = $this->loginapi->imgget('images',$img);

		if($get)
		{
        	$responce = array(
                
                'status' => '5',
                'success' => true,
                'mesg' => 'data selected',
                'data' => $get
        	);
        	echo json_encode($responce);
        }
        else
        {
        	$responce = array(
                
                'status' => '77',
                'success' => false,
                'mesg' => 'data not selected',
        	);
        	echo json_encode($responce);
        }
	}

	public function ipost()
	{
		$pimg = array(
			'ship_id' => $this->input->post('ship_id'),
			'file_name' => $this->input->file('file_name')
		);

		$post = $this->loginapi->imgpost('images',$pimg);

		if($post)
		{
        	$responce = array(
                
                'status' => '577',
                'success' => true,
                'mesg' => 'data inserted',
                'data' => $post
        	);
        	echo json_encode($responce);
        }
        else
        {
        	$responce = array(
                
                'status' => '57',
                'success' => false,
                'mesg' => 'data not inserted'
        	);
        	echo json_encode($responce);
        }

	}

	public function idel()
	{
		$id = $this->input->post('id');
		$delt = $this->loginapi->imgdel($id);

		if($delt)
        {
        	$responce = array(
                
                'status' => '775',
                'success' => true,
                'mesg' => 'data deleted',
                'data' => $delt
        	);
        	echo json_encode($responce);
        }
        else
        {
        	$responce = array(
                
                'status' => '75',
                'success' => false,
                'mesg' => 'data not deleted',
        	);
        	echo json_encode($responce);
        }
	}

	public function iupdate()
	{
		$upd = array(
            'ship_id' => $this->input->post('ship_id'),
			'file_name' => $this->input->post('file_name')
		);
        
        $id = $this->input->post('id');
		$update = $this->loginapi->imgupdate('images',$upd,array('id'=>$id));

		if($update)
        {
        	$responce = array(
                
                'status' => '7775',
                'success' => true,
                'mesg' => 'data updated',
                'data' => $update
        	);
        	echo json_encode($responce);
        }
        else
        {
        	$responce = array(
                
                'status' => '775',
                'success' => true,
                'mesg' => 'data not updated',
        	);
        	echo json_encode($responce);
        }
	}
}


?>