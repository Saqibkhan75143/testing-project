<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Regapi extends CI_Controller
{
	public function uget()
	{
       $userget = array(

       	  'email' => $this->input->post('email'),
       	  'first_name' => $this->input->post('first_name'),
       	  'last_name' => $this->input->post('last_name'),
       	  'password' => md5($this->input->post('password'))
       );
       $get = $this->loginapi->regget('users',$userget);
       if ($get) 
       {
       	  $responce = array(
              'status' => '1',
              'success' => true,
              'mesg' => 'data selected',
              'data' => $get
       	  );   
       	  echo json_encode($responce);
       }
       else
       {
       	  $responce = array(
              'status' => '2',
              'success' => false,
              'mesg' => 'data not selected'
       	  );   
       	  echo json_encode($responce);
       }
	}

	public function upost()
	{
		$userpost = array(
              
              'email' => $this->input->post('email'),
              'first_name' => $this->input->post('first_name'),
              'last_name' => $this->input->post('last_name'),
              'password' => md5($this->input->post('password'))
		);

		$post = $this->loginapi->regpost('users',$userpost);
		if ($post) 
		{
			$responce = array(
				'stutas' => '5',
				'success' => true,
				'mesg' => 'data inserted',
				'data' => $post
			);
			echo json_encode($responce);
		}
		else
		{
			$responce = array(
				'stutas' => '5',
				'success' => true,
				'mesg' => 'data not inserted',
				
			);
		}
	}

	public function udel()
  {
    $id = $this->input->post('id');
    $del = $this->loginapi->regdelete($id);

    if ($del) 
    {
      $responce = array(
        'status' => '5',
        'success'=> true,
        'mesg' => 'data delete',
        'data' => $del
      );
      echo json_encode($responce);
    }
    else
    {
      $responce = array(
        'status' => '5',
        'success'=> false,
        'mesg' => 'data not delete'
      );
      echo json_encode($responce);
    }
  }

  public function uput()
  {
    $put = array(
      'email' => $this->input->post('email'),
      'first_name' => $this->input->post('first_name'),
      'last_name' => $this->input->post('last_name'),
      'password' => md5($this->input->post('password'))
    );
    $userid = $this->input->post('id');
    $updte = $this->loginapi->regput('users',$put,array('id'=>$userid));

    if(!empty($updte))
    {
      $responce = array(
           'status' => '5',
           'success' => true,
           'mesg' => 'data updated',
           'data' => $updte
      );
      echo json_encode($responce);
    }
    else
      {
      $responce = array(
           'status' => '5',
           'success' => false,
           'mesg' => 'data not updated'
      );
      echo json_encode($responce);
    }
  }
}



?>