<?php 
defined('BASEPATH') OR exit('No direct script access allowed');


class Userapi extends CI_Controller
{
	

	public function user_get()
	{

		$shipments = array(
			'email' => $this->input->post('email'),
			'password' => md5($this->input->post('password'))
		);
		$get = $this->loginapi->get('users',$shipments);

		if(!empty($get))
		{
			$responce = array(
				'status' => '250',
				'success' => true,
				'msg' => 'data is selected',
              	'data' => $get
			);
			echo json_encode($responce);
		}
		else
		{
			$responce = array(
				'status' => '500',
				'success' => false,
				'msg' => 'data not selected'
			);
			echo json_encode($responce);
		}
	}

	public function user_post()
	{
		$userdata = array(
			'email' => $this->input->post('email'),
			'password' => md5($this->input->post('password'))
		);


		$post = $this->loginapi->post('users',$userdata);
		if($post)
		{
			$responce = array(
				'status' => '5',
				'success'=> true,
				'mesg' => 'data inserted',
				'data' => $post
			);
			echo json_encode($responce);
		}
		else
		{
			$responce = array(
				'status' => '10',
				'success'=> false,
				'mesg' => 'data not inserted'
			);
			echo json_encode($responce);
		}
	}

	public function user_del()
	{
        $id = $this->input->post('id');
		$del = $this->loginapi->delete($id);

		if ($del) 
		{
			$responce = array(
				'status' => '5',
				'success'=> true,
				'mesg' => 'data delete',
				'data' => $del
			);
			echo json_encode($responce);
		}
		else
		{
			$responce = array(
				'status' => '5',
				'success'=> false,
				'mesg' => 'data not delete'
			);
			echo json_encode($responce);
		}
	}

	public function user_put()
	{
		$put = array(
			'email' => $this->input->post('email'),
			'password' => md5($this->input->post('password'))
		);

		$userid = $this->input->post('id');
		$update = $this->loginapi->put('users',$put,array('id'=>$userid));

		if (!empty($update)) 
		{
			$responce = array(	
				'status' => '5',
				'success'=> true,
				'mesg' => 'update successfully',
				'data' => $update
			);
			echo json_encode($responce);
		}
		else
		{
			$responce = array(
				'status' => '7',
				'success' => false,
				'mesg' => 'update failed'
			);
			echo json_encode($responce);
		}

	}
}


?>