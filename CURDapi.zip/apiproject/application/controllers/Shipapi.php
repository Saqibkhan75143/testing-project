<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Shipapi extends CI_Controller
{
	public function sget()
	{

		// $get = $this->loginapi->get($id);
            $shipmnt = array(
            	'id' => $this->input->post('id'),
		 	
            );
         // $userid = $this->input->post('user_id');
		 $get = $this->loginapi->get('shipments',$shipmnt);

		if($get)
		{
			$responce = array(
				'status' => '2',
				'success' => true,
				'mesg' => 'data selected',
				'data' => $get
			);
			echo json_encode($responce);
		}
		else
		{
			$responce = array(
				'status' => '14',
				'success' => false,
				'mesg' => 'data not selected'
			);
			echo json_encode($responce);
		}
	}

	public function spost()
	{
		$ins = array(
            
			'order_no' => $this->input->post('order_no'),
			'customer' => $this->input->post('customer'),
			'description' => $this->input->post('description'),
			'notes_shipping' => $this->input->post('notes_shipping'),
			'notes_production' => $this->input->post('notes_production'),
		    'user_id' => $this->input->post('user_id'),
			'status' => $this->input->post('status')
		);
         
		$postt = $this->loginapi->post('shipments',$ins);

		if($postt)
		{
			$responce = array(
                 'status' => '5',
                 'success' => true,
                 'mesg' => 'data inserted',
                 'data' => $postt

			);
			echo json_encode($responce);
		}
		else
		{
			$responce = array(
                 'status' => '7',
                 'success' => false,
                 'mesg' => 'data not inserted'

			);
			echo json_encode($responce);
		}
	}

	public function sdel()
	{
	   
	   $id = $this->input->post('id');
       $dell = $this->loginapi->shipdelete($id);

        if($dell)
        {
        	$responce = array(
                
                'status' => '5',
                'success' => true,
                'mesg' => 'data deleted',
                'data' => $dell
        	);
        	echo json_encode($responce);
        }
        else
        {
        	$responce = array(
                
                'status' => '7',
                'success' => false,
                'mesg' => 'data not deleted',
        	);
        	echo json_encode($responce);
        }
	}

	public function supdate()
	{
		$upd = array(
            
			'order_no' => $this->input->post('order_no'),
			'customer' => $this->input->post('customer'),
			'description' => $this->input->post('description'),
			'notes_shipping' => $this->input->post('notes_shipping'),
			'notes_production' => $this->input->post('notes_production'),
		    'user_id' => $this->input->post('user_id'),
			'status' => $this->input->post('status')
		);

		$userid = $this->input->post('id');
		$update = $this->loginapi->shipupdate('shipments',$upd,array('id'=>$userid));

		if($update)
		{
        	$responce = array(
                
                'status' => '222',
                'success' => true,
                'mesg' => 'data updated',
                'data' => $update
        	);
        	echo json_encode($responce);
        }
        else
        {
        	$responce = array(
                
                'status' => '577',
                'success' => false,
                'mesg' => 'data not updated',
        	);
        	echo json_encode($responce);
        }
	}
}


?>