<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class loginapi extends CI_Model
{
	 public function get($table,$data)
	 {
	 	$this->db->where($data);
	 	$query = $this->db->from($table)   
	 	                  ->get();
    	         return $query->result_array();
	 }

	 public function post($table,$data)
	 {
	 	return $this->db->insert($table,$data);
	 }

	 public function delete($id)
	 {
	 	 return $this->db->delete('users',array('id'=>$id));

	 	// conditinal oprator
	 	// return $delete?true:false;
	 }

	 public function put($table, $data,$id)
	 {
	 	// UPDATE users SET email = '$email' WHERE id = '$id';
        return $this->db->where($id)
                        ->update($table, $data);
	 }

	 public function regget($table,$data)
	{
       $this->db->where($data);
       $que = $this->db->from($table)
                       ->get();
           return $que->result_array();
	}

	public function regpost($table,$data)
	{
       return $this->db->insert($table,$data);
	}

	public function regdelete($id)
	 {
	 	 return $this->db->delete('users',array('id'=>$id));

		
	}

	public function regput($table,$data,$id)
	{
      return  $this->db->where($id)
                ->update($table,$data);
	}

	public function shipget($table,$id)
	{
	 	$this->db->where($id);
	 	$q = $this->db->from($table)
	               ->get();
	 	         
	 	 return $q->result_array();

	}

	public function shippost($table,$data)
	{
        return $this->db->insert($table,$data);
	}

	public function shipdelete($id)
	{
		return $this->db->delete('shipments',array('id'=>$id));
	}

	public function shipupdate($table,$data,$id)
	{
        return $this->db->where($id)
                        ->update($table,$data);
	}

	public function imgget($table,$id)
	{
        $this->db->where($id);
        $que = $this->db->from($table)
                        ->get();
                return $que->result_array();
	}

	public function imgpost($table,$data)
	{
		return $this->db->insert($table,$data);
	}

	public function imgdel($id)
	{
		return $this->db->delete('images',array('id'=>$id));
	}

	public function imgupdate($table,$data,$id)
	{
       return $this->db->where($id)
                       ->update($table,$data);
	}
}

?>