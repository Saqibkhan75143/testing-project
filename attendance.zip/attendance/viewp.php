<?php 
$conn = mysqli_connect("localhost","root","");
        mysqli_select_db($conn , "attnd");

?>

<html>
<head>
	<link href="style.css" rel="stylesheet" id="bootstrap-css">
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<!--Pulling Awesome Font -->
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">


</head>
<body>
    
    <div class="panel panel-default container">

    	<div class="penel-heading">
    		<h1 style="text-align: center;">Attendance Mangement System</h1>
    	</div>

    	<div class="penel-body">
    		<a href="#" class="btn btn-primary">View</a>
    		<a href="Add.php" class="btn btn-primary pull-right">Add</a>


            <form method="post">
    		<table class="table">
    		  <thead>
                <tr>
    		    <th>Sr No.</th>
    		    <th>Name</th>
    		    <th>Father Name</th>
    		    <th>Email</th>
    		    <th>Attendance</th>
                </tr>
    		  	
    		  </thead>
<?php 

    if($_GET['date']){
       $date = $_GET['date'];

     $que = "SELECT emp.*,attendance.* from attendance
         inner join emp on attendance.emp_id=emp.id and attendance.date='$date'";

     $re = $conn->query($que);


     if ($re->num_rows > 0) {
         $i = 0;
         while ($val = $re->fetch_assoc()) {
             $i++;

?>



              <tr>
                  <td><?php echo $i; ?></td>
                  <td><?php echo $val['name']; ?></td>
                  <td><?php echo $val['fname']; ?></td>
                  <td><?php echo $val['email']; ?></td>
                  <td>
                  	
                  	Present <input type="radio"
                    
                    value="Present"
                    <?php
                     
                     if($val['value']=='Present')
                     	echo "checked";

                    ?> 

                  	>

                  	Absent <input type="radio"
                    
                    value="Absent"
                    <?php
                     
                     if($val['value']=='Absent')
                     	echo "checked";

                    ?> 

                  	>


                  </td>
                  
                  
              </tr>
                
               <?php } } }  ?>

    	</div>

    	<div class="penel-footer">
    		
    	</div>
    	
    </div>

</body>
</html>