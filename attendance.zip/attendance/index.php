<?php 
$conn = mysqli_connect("localhost","root","");
        mysqli_select_db($conn , "attnd");

?>

<html>
<head>
	<link href="style.css" rel="stylesheet" id="bootstrap-css">
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<!--Pulling Awesome Font -->
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">


</head>
<body>
    
    <div class="panel panel-default container">

    	<div class="penel-heading">
    		<h1 style="text-align: center;">Attendance Mangement System</h1>
    	</div>

    	<div class="penel-body">
    		<a href="view.php" class="btn btn-primary">View</a>
    		<a href="Add.php" class="btn btn-primary pull-right">Add</a>


            <form method="post">
    		<table class="table">
    		  <thead>
    		  	<tr>
    		    <th>Name</th>
    		    <th>Father Name</th>
    		    <th>Email</th>
    		    <th>Attendance</th>	
                </tr>
    		  	
    		  </thead>

                
               
               <tbody>
               	
    <?php 
        
        $que = "select * from emp";
        $res = mysqli_query($conn , $que);
        while($show = mysqli_fetch_assoc($res)){

    ?>

                <tr>
                	<td><?php echo $show['name'] ?></td>
                	<td><?php echo $show['fname'] ?></td>
                	<td><?php echo $show['email'] ?></td>
                	<td>
                		
                       Present <input  type="radio" name="attendance[<?php echo $show['id']; ?>]" value="Present">
                       Absent <input  type="radio" name="attendance[<?php echo $show['id']; ?>]" value="Absent">

                	</td>
                </tr>

                <?php } ?>

        

               </tbody>

<?php 

     if (isset($_POST['submit'])) {
     	
     	 $att = $_POST['attendance'];
         
     	$date = date('d-m-y');

     	$q = "select distinct date from attendance";
     	$r = mysqli_query($conn , $q);
     	$b = false;
     	
     	if ($r->num_rows > 0) {
     	
     	while ($check = $r->fetch_assoc()) {
     		
     		if($date == $check['date']){
     		$b=true;

     		echo "<div class='alert alert-danger'>

               Attendance already taken today!!;

               </div>";
     	}
     	}
     }

     	if (!$b) {
     		  foreach ($att as $key => $value) {
     		  	if($value == "Present"){

     		  		$qu = "insert into attendance(value , emp_id , date) values('Present',$key,'$date')";
     		  		$re = mysqli_query($conn , $qu);
     		  	}
     		  	else{

     		  		$qu = "insert into attendance(value , emp_id , date) values('Absent',$key,'$date')";
     		  		$re = mysqli_query($conn , $qu);
     		  	}
     		  }

     		  if ($re) {
     		  	echo "<div class='alert alert-success'>

               Attendance taken successfully!!;

               </div>";
     		  }
     	}
     
 }

?>
               

    		</table>
    		<input type="submit" name="submit" class="btn btn-primary" value="Take Attendance">
    		
            </form>

    	</div>

    	<div class="penel-footer">
    		
    	</div>
    	
    </div>

</body>
</html>