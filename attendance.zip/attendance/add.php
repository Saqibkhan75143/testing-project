<?php 
$conn = mysqli_connect("localhost","root","");
        mysqli_select_db($conn , "attnd");

?>

<html>
<head>
	<link href="style.css" rel="stylesheet" id="bootstrap-css">
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<!--Pulling Awesome Font -->
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">


</head>
<body>
    
    <div class="panel panel-default container">

    	<div class="penel-heading">
    		<h1 style="text-align: center;">Attendance Mangement System</h1>
    	</div>

    	<div class="penel-body">
<?php 
      
      if (isset($_POST['submit'])) {
        
           $name = $_POST['name'];
           $fname= $_POST['fname'];
           $email= $_POST['email'];

           if ($name=="" || $fname==""  || $email=="") {
               echo "<div class='alert alert-danger'>

                Fields must not be empty;

               </div>";
           }
           else if (!filter_var($email,FILTER_VALIDATE_EMAIL)) {
               
               echo "<div class='alert alert-danger'>

               Invalid email format!!;

               </div>";


           }

           else{

           $que = "insert into emp(name , fname , email) values('$name' , '$fname' , '$email')";
           $res = mysqli_query($conn , $que);

           if ($res) {
               echo "<div class='alert alert-success'>
                     
                     Data inserted successfully;

               </div>";
           }

           }

      }



?>




            <form method="post">
    		<a href="#" class="btn btn-primary">View</a>
    		<a href="index.php" class="btn btn-primary pull-right">Back</a>

            <div class="form-group">
            <label>Name:</label>
            <input type="text" name="name" class="form-control">
            </div>

            <div class="form-group">
            <label>Father Name:</label>
            <input type="text" name="fname" class="form-control">
            </div>

            <div class="form-group">
            <label>Email:</label>
            <input type="text" name="email" class="form-control">
            </div>

            <input type="submit" name="submit" class="btn btn-primary">
            </form>


    	</div>

    	<div class="penel-footer">
    		
    	</div>
    	
    </div>

</body>
</html>