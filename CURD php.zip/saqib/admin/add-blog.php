<?php 
$conn = mysqli_connect("localhost" , "root" , "");
        mysqli_select_db($conn , "admin");
      
       if (isset($_POST['submit'])) {
         
         $name  = $_POST['name'];
         $date  = $_POST['date'];

         $photo = $_FILES['photo']['name'];
         $type  = $_FILES['photo']['type'];
         $size  = $_FILES['photo']['size'];
         $temp  = $_FILES['photo']['tmp_name'];

         if ($type == 'image/png' || $type == 'image/jpg' || $type == 'image/jpeg'){

            if($size <= 9876555444){

              if(move_uploaded_file($temp, "upload/".$photo)){

             $query  = "insert into blog (name , date , photo) value ('$name' , '$date' , '$photo') ";

             $result = mysqli_query($conn , $query);

                if ($result) {
           
                  header('location:btable.php?pass');

         }

                   else{

                  header('location:add-blog.php?failed');

                 }

              }

              else{

                echo "file uploaded fail";

              }

            }

            else{

              echo "size is less than req";

            }

         }

         else {

           echo "image type is not matched";
         
         }

    }

?>



<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition register-page">

  <div class="wrapper">


  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      
      <!-- search form -->
      
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>

        <li class="treeview">
          <ul>
            <br><br>
            <li>
              <a href="index.php">Login</a>
            </li>
            
            <br>
            <li>
              <a href="logout.php">Logout</a>
            </li>

             <br>
            <li>
              <a href="add-category.php">Add Category</a>
            </li>

            <br>
            <li>
              <a href="table.php">Category Table</a>
            </li>

            <br>
            <li>
              <a href="add-product.php">Add Product</a>
            </li>

            <br>
            <li>
              <a href="ptable.php">Product Table</a>
            </li>
            <br>
            <li>
              <a href="add-portfolio.php">Add Portfolio</a>
            </li>
            <br>
            <li>
              <a href="potable.php">Portfolio Table</a>
            </li>
            <br>
            <li>
              <a href="add-team.php">Add Team</a>
            </li>
            <br>
            <li>
              <a href="ttable.php">Team Table</a>
            </li>
            <br>
            <li>
              <a href="add-blog.php">Add Blog</a>
            </li>
            <br>
            <li>
              <a href="btable.php">Blog Table</a>
            </li>
            <br>
            <li>
              <a href="contact.php">Contact Table</a>
            </li>

      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="ion ion-ios-gear-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">CPU Traffic</span>
              <span class="info-box-number">90<small>%</small></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-google-plus"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Likes</span>
              <span class="info-box-number">41,410</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <div class="clearfix visible-sm-block"></div>

        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="ion ion-ios-cart-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Sales</span>
              <span class="info-box-number">760</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="ion ion-ios-people-outline"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">New Members</span>
              <span class="info-box-number">2,000</span>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
      </div>

<div class="register-box">

  <div class="register-box-body">
    <p class="login-box-msg">Add Blog</p>

    <form method="post" enctype="multipart/form-data">

      <div class="form-group">
        <label>Name</label>
        <input type="text" name="name" class="form-control"> 
      </div>

      <div class="form-group">
        <label>Date</label>
        <input type="date" name="date" class="form-control"> 
      </div>

      <div class="form-group">
        <label>Photo</label>
        <input type="file" name="photo" class="form-control"> 
      </div>



      <div class="row">
        <div class="col-xs-4">
          
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" name="submit" class="btn btn-primary btn-block btn-flat">submit</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

   

    
  </div>
  <!-- /.form-box -->
</div>


    </section>
    <!-- /.content -->
  </div>

  <!-- /.content-wrapper -->

 
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>

</div>


<!-- /.register-box -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' /* optional */
    });
  });
</script>
</body>
</html>
