<?php 
session_start();
$conn = mysqli_connect("localhost" , "root" , "");
        mysqli_select_db($conn , "admin");

        		//print_r($_POST);
        		//die;
        if (isset($_POST['update'])) {
        	
            $name = $_POST['name'];
            $id   = $_POST['id'];

            $query  = "UPDATE `portfolio` set `name` = '$name' where `id` = '$id'";
            $result = mysqli_query($conn , $query);

            if ($result) {
            	
            	header('location:potable.php?successful');

            }

            else{

            	header('location:poedit.php?edit_id="'.$id.'"');
            }

        }


?>