<?php 
session_start();
$conn = mysqli_connect("localhost" , "root" , "");
$db   = mysqli_select_db($conn , "admin");

          if(isset($_GET['del_id'])){

          $del = $_GET['del_id'];

          $query = "delete from products where id = '$del' ";
          $res   = mysqli_query($conn , $query);

          if ($res) {
     	
          header('location:ptable.php?successful');

          }

          else{

          header('location:ptable.php?failed');

     }

  }



?>