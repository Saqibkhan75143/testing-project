<?php 
session_start();
$conn = mysqli_connect("localhost" , "root" , "");
        mysqli_select_db($conn , "admin");

        if (isset($_GET['del_id'])) {
        	
        	$del = $_GET['del_id'];

        	$query  = "delete from team where id = '$del'";
        	$result = mysqli_query($conn , $query);

        	if ($result){
        		
        		header('location:ttable.php?success');
        	
        	}

        	else{

        		header('location:ttable.php?false');
        	}

        }


?>