<?php 
session_start();
$conn = mysqli_connect("localhost" , "root" , "");
$db   = mysqli_select_db($conn , "admin");

  if(isset($_GET['del_id'])){

       $del_id = $_GET['del_id'];

       $query = "delete from portfolio where id = '$del_id' ";
       $result = mysqli_query($conn , $query);

       if($result){

          header('location:potable.php?success');

       }

       else{

          header('location:potable.php?failed');

       }

  }


?>