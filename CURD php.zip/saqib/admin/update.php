<?php  
session_start();
$conn = mysqli_connect("localhost" , "root" , "");
        mysqli_select_db($conn , "admin");

        if(isset($_POST['update'])){
             
             $name = $_POST['name'];
             $id   = $_POST['id'];


        $query  = "UPDATE `category` SET name = '$name' WHERE id = '$id'";

        $result = mysqli_query($conn , $query);

        if ($result) {
        	
             header('location:table.php?success');

        }

        else{

        	header('location:edit.php?failed');
        }

        }




?>