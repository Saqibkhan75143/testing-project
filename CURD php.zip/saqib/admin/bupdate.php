<?php 
session_start();
$conn = mysqli_connect("localhost" , "root" , "");
        mysqli_select_db($conn , "admin");

        if (isset($_POST['update'])) {
        	
        	$name = $_POST['name'];
        	$date = $_POST['date'];
        	$id   = $_POST['id'];

        	$query  = "update blog set name = '$name' , date = '$date' where id = '$id'";
        	$result = mysqli_query($conn , $query);

        	if ($result) {
        		
        		header('location:btable.php?success');

        	}

        	else {

        		header('location:bedit.php?edit_id="'.$id.'"');

        	}
        }


?>