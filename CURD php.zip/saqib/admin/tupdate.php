<?php 
session_start();
$conn = mysqli_connect("localhost" , "root" , "");
        mysqli_select_db($conn , "admin");

      if (isset($_POST['update'])) {
   	    
   	       $name      = $_POST['name'];
           $prof      = $_POST['prof'];
           $facebook  = $_POST['facebook'];
           $twitter   = $_POST['twitter'];
           $instagram = $_POST['instagram'];
           $id        = $_POST['id'];

        $query  = "update team set name = '$name' , professional = '$prof' , facebook = '$facebook' , twitter = '$twitter' , instagram = '$instagram' where id = '$id' ";

        $result = mysqli_query($conn , $query);

        if ($result) {
        	
        	header('location:ttable.php?successful');

        }

        else{

        	header('location:tedit.php?edit_id="'.$id.'"');

        }

      }


?>