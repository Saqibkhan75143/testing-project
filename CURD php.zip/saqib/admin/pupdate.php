<?php 
$conn = mysqli_connect("localhost" , "root" , "");
        mysqli_select_db($conn , "admin");

        if(isset($_POST['update']) && $_POST['update'] == 'update'){

          $name         = $_POST['name'];
          $price        = $_POST['price'];
          $saleprice    = $_POST['sale_price'];
          $salediscount = $_POST['sale_discount'];
          $category     = $_POST['category'];
          $id           = $_POST['id'];

        $query = "UPDATE `products` SET `name` = '$name' , `price` = '$price' , `sale_price` = '$saleprice' , `sale_discount` = '$salediscount' , `category_id` = '$category' WHERE `id` = '$id' ";

        $result = mysqli_query($conn , $query);

        if ($result) {
        	
        	header('location:ptable.php?action=successful');

        }

        else{

           header('location:pedit.php?edit_id='.$id.'&action=failed');

        }

        }



?>