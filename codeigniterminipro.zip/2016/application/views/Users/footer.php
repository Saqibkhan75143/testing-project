<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="<?= base_url("Assets/js/bootstrap.js") ?>"></script>
<div class="footer-copyright">
<div class="container">
  © 2018 Copyright: <a href="https://www.TP2K16.com"> TP2K16.com </a>
</div>
</div>
</body>
</html>