<html>
<head>
<title>Article List</title>
<?= link_tag("Assets/css/bootstrap.min.css") ?>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="<?php echo base_url()?>admin/welcome">Article List</a>
  <a class="navbar-brand" href="<?php echo base_url()?>export">User Feedback</a>
  <a class="navbar-brand" href="<?php echo base_url()?>Dynamic_dependent">Drop Down Demo</a>
  <a class="navbar-brand" href="<?php echo base_url()?>index.php/login">Admin Login</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarColor01">
   
    
  </div>
</nav>