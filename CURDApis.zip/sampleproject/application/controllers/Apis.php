<?php 



class Apis extends CI_Controller
{
	
	function __construct()
	{
	   parent::__construct();
	}

	function getuser()
	{
	  $user = $this->general->get('users');

	  if (!empty($user)) 
	  {
	  	 $response = array(
	  	 	'status' => '300',
	  	 	'success' => true,
	  	 	'mesg' => 'user are selected',
	  	 	'data' => $user
	  	 );
	  	 echo json_encode($response);
	  	}
	  	 
	  	 else
	  	 {
	  	 	$response = array(
	  	 	'status' => '500',
	  	 	'success' => false,
	  	 	'mesg' => 'user not selected'
	  	 );
	  	 	echo json_encode($response);
	  	 }
	  	 
	}

	function getshipments()
	{
	  $ship = $this->general->get('shipments','','','');

	  if (!empty($ship)) 
	  {
	  	 $response = array(
	  	 	'status' => '300',
	  	 	'success' => true,
	  	 	'mesg' => 'ship are selected',
	  	 	'data' => $ship
	  	 );
	  	 echo json_encode($response);
	  	}
	  	 
	  	 else
	  	 {
	  	 	$response = array(
	  	 	'status' => '500',
	  	 	'success' => false,
	  	 	'mesg' => 'ship not selected'
	  	 );
	  	 	echo json_encode($response);
	  	 }
	  	 
	}

	function getuserbyid()
	{
	  $userid = $this->input->get('userid');
	  $users = $this->general->get('users',array('id'=>$userid));

	  if (!empty($users)) 
	  {
	  	 $response = array(
	  	 	'status' => '300',
	  	 	'success' => true,
	  	 	'mesg' => 'users are selected',
	  	 	'data' => $users
	  	 );
	  	 echo json_encode($response);
	  	}
	  	 
	  	 else
	  	 {
	  	 	$response = array(
	  	 	'status' => '500',
	  	 	'success' => false,
	  	 	'mesg' => 'users not selected'
	  	 );
	  	 	echo json_encode($response);
	  	 }
	  	 
	}

	function getshipmentbyid()
	{
		echo $this->general->counttable('shipments');
		$shipmentid = $this->input->get('shipmentid');
	  $shipment = $this->general->get('shipments',array('id'=>$shipmentid));

	  if (!empty($shipment)) 
	  {
	  	 $response = array(
	  	 	'status' => '300',
	  	 	'success' => true,
	  	 	'mesg' => 'shipment are selected',
	  	 	'data' => $shipment
	  	 );
	  	 echo json_encode($response);
	  	}
	  	 
	  	 else
	  	 {
	  	 	$response = array(
	  	 	'status' => '500',
	  	 	'success' => false,
	  	 	'mesg' => 'shipment not selected'
	  	 );
	  	 	echo json_encode($response);
	  	 }
	  	 
	}

	function postuser()
	{
		$user = array(
			'email' => $this->input->post('email'),
			'first_name' => $this->input->post('first_name'),
			'last_name' => $this->input->post('last_name'),
			'password' => md5($this->input->post('password'))
		);

		$post = $this->general->post('users',$user);

		if (!empty($post)) 
		{
			$response = array(
               'status' => '399',
               'success' => true,
               'mesg' => 'user inserted',
               'data' => $post
			);
			echo json_encode($response);
		}
		else
		{
			$response = array(
               'status' => '500',
               'success' => false,
               'mesg' => 'user not inserted'
			);
			echo json_encode($response);
		}
	}

	function postshipments()
	{
		$ship = array(
			'order_no' => $this->input->post('order_no'),
			'customer' => $this->input->post('customer'),
			'description' => $this->input->post('description'),
			'notes_shipping' => $this->input->post('notes_shipping'),
			'notes_production' => $this->input->post('notes_production'),
			'user_id' => $this->input->post('user_id'),
			'status' => $this->input->post('status')
		);

		$shipment = $this->general->post('shipments',$ship);

		if (!empty($shipment)) 
		{
			$response = array(
               'status' => '399',
               'success' => true,
               'mesg' => 'user inserted',
               'data' => $shipment
			);
			echo json_encode($response);
		}
		else
		{
			$response = array(
               'status' => '500',
               'success' => false,
               'mesg' => 'user not inserted'
			);
			echo json_encode($response);
		}
	}

    function userdelete()
    {
      $deleteid = $this->input->post('deleteid');
      $dell = $this->general->delete($deleteid);

      if($dell)
      {
      	$response = array(
           'status' => '333',
           'success' => true,
           'mesg' => 'data delete',
           'data' => $dell
      	);
      	echo json_encode($response);
      }
      else
      {
      	$response = array(
           'status' => '350',
           'success' => false,
           'mesg' => 'data not delete'
      	);
      	echo json_encode($response);
      }
    }
    function userupdate()

    {
    	$update = array(

    		'email' => $this->input->post('email'),
			'first_name' => $this->input->post('first_name'),
			'last_name' => $this->input->post('last_name'),
			'password' => md5($this->input->post('password'))
    	);

    	$updateid = $this->input->post('updateid');
    	$userupdate = $this->general->update('users',$update,array('id'=>$updateid));

    	
    	if(!empty($userupdate))
    	{
    	   $response = array(
               'status' => '50',
               'success' => true,
               'mesg' => 'user update',
               'data' => $userupdate
			);
			echo json_encode($response);	
    	}
    	else
    	{
    	   $response = array(
               'status' => '70',
               'success' => false,
               'mesg' => 'user not update'
			);
			echo json_encode($response);	
    	}
    }

    function imageget()
	{
        $imageget = $this->general->get('images');

		if($imageget)
		{
        	$responce = array(
                
                'status' => '5',
                'success' => true,
                'mesg' => 'data selected',
                'data' => $imageget
        	);
        	echo json_encode($responce);
        }
        else
        {
        	$responce = array(
                
                'status' => '77',
                'success' => false,
                'mesg' => 'data not selected',
        	);
        	echo json_encode($responce);
        }
	}

		 public function imgpost()
		 {
			
		 	 $config['upload_path'] = './upload/';
		 	 $config['allowed_types'] = 'gif|jpg|png';
		 	 $this->load->library('upload',$config);

		 	 $this->upload->do_upload('file_name');
		  	 // $data = $this->input->post();
		 	 	$info = $this->upload->data();

                  $image_path = ($info['raw_name'].$info['file_ext']);
				
                  $data['file_name'] = $image_path;

				
		 	 	$img = $this->general->post('images',$data);
		 		if($img)
		 		{
                  $responce = array(
                     'status' => '500',
                     'success' => true,
                     'mesg' => 'data inserted',
                     'data' => $img
         	);
         	echo json_encode($responce);
		 		}

		 		else
		 		{
		 		  $responce = array(
                     'status' => '505',
                     'success' => false,
                     'mesg' => 'data not inserted'
         	);
         	echo json_encode($responce);
		 		}

		 	}

          
         // For Controller file upload

		 	// Paste in Controller

            // $pictureName = $_FILES['image']['name'];
            // $pictureTemp = $_FILES['image']['tmp_name'];
            // $UploadFile  = $this->Database->fileUpload($pictureName,$pictureTemp,'uploads');
            // $picture      = $UploadFile['filename'];
			
	

}






?>