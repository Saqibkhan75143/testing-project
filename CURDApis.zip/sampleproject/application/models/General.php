<?php 

/**
 * 
 */
class General extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}

	function get($table,$condition = null,$orderby = null,$limit = null)
	{
		if(!empty($condition)){
		$this->db->where($condition);
        }

        if(!empty($orderby)){
		$this->db->order_by($orderby);
        }

        if(!empty($limit)){
		$this->db->limit($limit);
        }

		$query = $this->db->get($table);
		return $query->result();
	}

	function counttable($table)
	{
		return $this->db->count_all($table);
	}

	function post($table,$data)
	{
		return $this->db->insert($table,$data);
	}

	function delete($condition)
	{
		return $this->db->delete('users',array('id'=>$condition));
	}

	function update($table,$data,$condition)
	{
       return $this->db->where($condition)
                       ->update($table,$data);
	}

	// function imgget($table,$condition)
	// {
 //        $this->db->where($condition);
 //        $que = $this->db->from($table)
 //                        ->get();
 //                return $que->result_array();
	// }




  // For Models file upload

	// function fileUpload($param,$temp)
 //    {
 //        // Allowing Files with extensions lists
 //        $allow_ext = array("png","jpg","jpeg","gif",'pdf','xlsx','csv','docx');
 //          // Checking Diretory if Exists then upload if not then create one
 //        // $uploadPath = 'upload/'.$location;
 //        // Now Uploading Files to Directory
 //        $FileReturn = '';

 //        if(!empty($param))
 //        {
 //            if($param !=''){
 //                $explode = explode(".", $param);
 //                $Ext = end($explode);
 //                $ext = strtolower($Ext);
 //                $fileName = date("Ymdhis").date("Ymdhis").rand(0,99999);

 //                if(in_array($ext, $allow_ext)){
 //                    move_uploaded_file($temp,$fileName.'.'.$ext);
 //                    $FileReturn = array(
 //                                    'orignal'=>$fileName.'.'.$ext,
 //                                    // 'filename'=>base_url().$uploadPath.'/'.$fileName.'.'.$ext,
 //                                    'ext'=> $ext,
 //                                    'image' => $fileName);
 //                    return $FileReturn;

 //                      // return $this->db->insert($param,$temp);


 //                }
 //                else{
 //                    $data['error_msg'] = "Please upload valid File";
 //                }
 //            }
 //        }
 //    }

}

?>