<?php 


class User_model extends CI_Model
{
	
	function create($formArray)
	{
		 $this->db->insert('users',$formArray); // INSERT INTO users (name,email) values($name,$email);
	}

	function all()
	{
		$user = $this->db->get('users');
		return   $user->result_array();
	}

	function getUser($userid)
	{
		$this->db->where('user_id',$userid);
	    $user = $this->db->get('users');
	    return $user->row_array(); // select * from users where user_id = ?
	}

	function updateUser($userid,$formArray)
	{
		$this->db->where('user_id',$userid);
		$this->db->update('users',$formArray ); // update users set name = ? , email = ? where user_id = ? ;
	}

	function deleteUser($userid)
	{
		$this->db->where('user_id',$userid);
		$this->db->delete('users'); // delete from users where user_id = ?
	}
}

?>